//declare html element 

const imgDiv = document .querySelector('.animal_photo');
const img = document .querySelector('#photo');
const file = document .querySelector('#file');
const uploadPhoto = document .querySelector('#uploadPhoto');

// hover in the image 
imgDiv.addEventListener('mouseenter', function(){
    uploadPhoto.style.display = "block";

});

imgDiv.addEventListener('mouseleave', function(){
    uploadPhoto.style.display = "none";
});

file.addEventListener('change', function(){
    const choosedFile = this.files[0];
    if(choosedFile){
        const reader= new FileReader();
        reader.addEventListener('reader',function(){
            img.setAttribute('src',reader.result);
        });
        reader.readAsDataURL(choosedFile);
    }
});

(document).ready(function(){
	(".popup-bg").delay(1200).fadeIn(600);
	(".popup-bg").on('click', function() {
		(this).fadeOut(800);
	});
		(".close-x").on('click', function() {
		(".popup-bg").fadeOut(800);
	});
});

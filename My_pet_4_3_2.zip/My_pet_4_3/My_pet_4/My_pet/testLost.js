function showPreview(event){
    if(event.target.files.length > 0){
      var src = URL.createObjectURL(event.target.files[0]);
      var preview = document.getElementById("photo");
      preview.src = src;

    }
}

file.onchange=(event)=>{
    console.log(event);
    showPreview(event);
}